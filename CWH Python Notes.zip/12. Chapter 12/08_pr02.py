list1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

for index, item in enumerate(list1):
    if(index+1 == 3 or index+1 == 5 or index+1 == 7):
        print(item) 
        
