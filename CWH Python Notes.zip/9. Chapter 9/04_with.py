with open("mine.txt", "w") as f:
    f.write("This file is mine")