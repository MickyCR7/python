myName = "My Name\nis \tHar\"ry"
print(myName)