myStr = "This is me  and  I  am a good boy"

print(myStr.replace("  ", " ")) 