a = int(input("Enter the number: "))
print("The square of this number is:", a *a)