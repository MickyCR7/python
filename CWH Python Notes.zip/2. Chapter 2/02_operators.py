a = 7
b = 3

# Arithmetic Operators in Python
print("a + b = ", a + b)
print("a - b = ", a - b)
print("a * b = ", a * b)
print("a / b = ", a / b)

# Assignment Operators in Python
print("Demonstrating Assignment Operators in Python")
c = 5
d = 7

print(c, d)
c +=  5
d += 1
print(c, d)


# Comparison Operators in Python
print("Demonstrating Comparison Operators in Python")
e = 6
f = 9

print(e==f)
print(e>f)
print(e<f)
print(e!=f)

# Logical Operators in Python
print("Demonstrating Logical Operators in Python")
e = 6
f = 9

print(e==f and e>f) 
print(e==f or e<f) 
print(not(e>f)) 