import pyttsx3
engine = pyttsx3.init()
engine.say("Hey Harry I am a python module. Welcome to the world of Python")
engine.runAndWait()