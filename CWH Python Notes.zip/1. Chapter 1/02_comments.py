'''
Author: Harry
Date: 
Time: 
'''

import time

print('Waiting for 1 second')
# Feel free to change the delay as per the instructions from your boss
time.sleep(1) 
print('Waiting for 1 second completed')