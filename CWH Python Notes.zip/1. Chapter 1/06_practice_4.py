# Author: Harry
# Organization: ProgrammingWithHarry

import os # Importing the module
print(os.listdir()) # Function to display all the directory content