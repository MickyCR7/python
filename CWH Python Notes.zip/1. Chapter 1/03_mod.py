import time
# import flask

# Waiting for 2 seconds
time.sleep(2)
print("2 Seconds have passed since this program ran")