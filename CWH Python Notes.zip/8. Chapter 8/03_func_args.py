def average(a, b, c):
    return (a + b + c) / 3

def greet(name='Harry'):
    return "Hello " + name
    
# avg = average(3, 6, 3)
# print(avg)

# a = greet("Shubh")
a = greet()
print(a)