myList = [1, 2, 4, 5]
sum = 0
sum += myList[0]
sum += myList[1]
sum += myList[2]
sum += myList[3]
print("The value of sum is", sum)