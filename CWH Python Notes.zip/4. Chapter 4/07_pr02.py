marks1 = int(input("Enter marks of student 1: "))
marks2 = int(input("Enter marks of student 2: "))
marks3 = int(input("Enter marks of student 3: "))
marks4 = int(input("Enter marks of student 4: "))
marks5 = int(input("Enter marks of student 5: "))
marks6 = int(input("Enter marks of student 6: "))

marksList = [marks1, marks2, marks3, marks4, marks5, marks6]
marksList.sort()
print(marksList)