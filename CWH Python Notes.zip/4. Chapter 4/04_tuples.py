# myTuple = (3, 6, 7)
myTuple = (4,)
print(myTuple)
# myTuple[0] = 8 # This will throw an error
print(type(myTuple))