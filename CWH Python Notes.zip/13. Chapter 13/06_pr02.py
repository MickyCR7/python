st = "The name of the student is {}, his marks are {} and phone number is {}"
a = st.format("Harry", 34, 9888888800)
print(a)