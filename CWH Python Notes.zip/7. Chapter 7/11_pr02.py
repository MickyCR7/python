l1 = ["shivam", "Soham", "Harry", "Deepika", "Sachin"]

for item in l1:
    if item.startswith("S"):
        print(f"Good morning {item}")