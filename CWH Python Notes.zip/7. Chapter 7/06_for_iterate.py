a = [1, "apple", 3, 4 , 5, "banana"]
i = 0
# for i in range(len(a)):
#     print(a[i])
#     i+=1

for item in a:
    print(item)