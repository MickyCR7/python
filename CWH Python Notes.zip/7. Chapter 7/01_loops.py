a = 0
while(a<100):
    print(a)
    a += 1